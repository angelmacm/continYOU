<div class="footer">
<footer class = "footer-container">
        <div class = "footer-first-division">
            <div>
                <a href="tel:09053010901"  class="footer-contacts">
                <i class="fa-solid fa-square-phone"></i>
                <p class = "contacts-number">Contact Us: 09053010901</p></a>
            </div>
            <div>
                <a href="https://www.facebook.com" target="_blank"><i class="fa-brands fa-facebook-square"></i></a>
                <a href="https://www.twitter.com" target="_blank"><i class="fa-brands fa-twitter-square"></i></a>
                <a href="https://www.instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            </div>
        </div>
        <hr>
        <div class = "footer-second-division">
            <p class = "creators">Group Two | WEB 224 | BSCpE-2A</p>
            <p class = "copyright">Copyright 2022 All Rights Reserved</p>
        </div>
    </footer>
        </div>